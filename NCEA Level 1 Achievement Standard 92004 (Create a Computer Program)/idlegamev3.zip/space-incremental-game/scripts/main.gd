extends Control
const save_path = "user://userdata.save"

var fuel = 0
var fuel_per_click = 1
signal resource_changed
# Called when the node enters the scene tree for the first time.

func save_data():
	var data = {
		"Fuel" : fuel,
		"Fuel Per Click": fuel_per_click
	}
	var file = FileAccess.open(save_path, FileAccess.WRITE)
	file.store_var(data)
	file.close

func load_data():
	if FileAccess.file_exists(save_path):
		var file = FileAccess.open(save_path, FileAccess.READ)
		var data = file.get_var()
		file.close()
		if typeof(data) == TYPE_DICTIONARY:
			fuel = data.get("Fuel", 0)
			fuel_per_click = data.get("Fuel Per Click", 1)
			emit_signal("resource_changed", fuel)
			return "file loaded"
		else:
			return "save invalid"
	else:
		return "no save present"

func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_fuelmine_button_down() -> void:
	fuel += fuel_per_click
	emit_signal("resource_changed", fuel)
	

func _on_save_button_down() -> void:
	save_data()

func _on_load_button_down() -> void:
	load_data()
	
